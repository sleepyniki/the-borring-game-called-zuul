 class Player 
{ 
// auto property 

// fields 
public int health; 

public Room CurrentRoom { get; set; } 
// constructor 
public Player() 
{ 
CurrentRoom = null; 
health = 100; 
}

// method to check health
public void Checkhealth()
{
    Console.WriteLine("the player has " + health + " health"); 
}


// methods 
public void Damage(int amount) {health -= amount; if (health < 0) {health = 0;} if (health == 0){Console.WriteLine("you have died"); } } // player loses some health 
public void Heal(int amount) {health += amount; Console.WriteLine("player health increased by " + amount);} // player's health restores 
public bool IsAlive() 
{ 
    return health > 0;  // checks whether the player is alive or not  
}

} 


