# Zuul

A boring textadventure.

## How to play

Install the latest [dotnet](https://dotnet.microsoft.com/en-us/download) or latest LTS version.

Open this directory (with the Zuul.csproj file) in the terminal and type:

```
dotnet run
```
